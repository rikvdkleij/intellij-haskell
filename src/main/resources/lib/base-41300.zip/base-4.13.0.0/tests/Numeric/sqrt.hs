main = do
    print (sqrt (-7 :: Double))
    print (sqrt (-7 :: Float))
