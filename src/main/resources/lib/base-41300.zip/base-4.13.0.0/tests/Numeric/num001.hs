module Main(main) where

import Numeric
import Data.Ratio

main = print ((fromRat (132874 % 23849))::Double)
