import Control.Concurrent

main :: IO ()
main = threadDelay maxBound
