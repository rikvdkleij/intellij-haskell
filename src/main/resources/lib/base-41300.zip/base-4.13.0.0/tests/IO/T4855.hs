import Debug.Trace

main = trace "我爱我的电脑" $ return ()