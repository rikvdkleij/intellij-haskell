import System.IO

main = isEOF >>= print
