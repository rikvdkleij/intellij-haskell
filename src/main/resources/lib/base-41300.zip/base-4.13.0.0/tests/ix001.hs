import Data.Ix
import Data.Int

main = print (index (minBound::Int16,maxBound) maxBound)
