module T9681 where

foo = 1 + "\n"
