
import Data.Ratio
main = print [ 1, 4%(3::Int) .. 1 ]
