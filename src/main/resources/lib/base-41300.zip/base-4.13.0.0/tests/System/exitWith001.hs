import System.Exit (exitWith, ExitCode(..))

main = exitWith (ExitFailure 42)
