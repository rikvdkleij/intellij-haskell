import Text.Printf
main = printf "%*sx\n" (-(3::Int)) "hi"
