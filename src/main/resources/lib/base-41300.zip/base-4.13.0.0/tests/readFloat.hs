
import Numeric

main :: IO ()
main = putStrLn $ showFloat (read "" :: Float) ""
