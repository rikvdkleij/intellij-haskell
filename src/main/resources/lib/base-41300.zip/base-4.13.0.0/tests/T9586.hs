module XPrelude (module X) where

import Control.Monad    as X
import Data.Foldable    as X
import Data.List        as X
import Data.Monoid      as X
import Data.Traversable as X
import Prelude          as X
