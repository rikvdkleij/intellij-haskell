import Data.Ratio

-- !!! Test that (%) has the right fixity
main = print (2^3%5)
