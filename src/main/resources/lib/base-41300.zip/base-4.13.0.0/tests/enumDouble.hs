
main :: IO ()
main = print (succ (1.0e20 :: Double))
