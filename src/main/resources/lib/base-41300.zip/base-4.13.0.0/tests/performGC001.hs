-- !!! test System.Mem.performGC

import System.Mem

main = performGC
